﻿using System;
using System.Windows.Forms;

using KeePass.UI;
using KeePass.Plugins;
using KeePassLib.Keys;
using KeePassLib.Utility;
using KeePassLib.Serialization;
using KeyProviderTest.Forms;

namespace KeyProviderTest
{
    public sealed class KeyProviderTestExt : Plugin
    {
        private IPluginHost m_host = null;
        private SampleKeyProvider m_prov = new SampleKeyProvider();

        public override bool Initialize(IPluginHost host)
        {
            m_host = host;

            m_host.KeyProviderPool.Add(m_prov);
            return true;
        }

        public override void Terminate()
        {
            m_host.KeyProviderPool.Remove(m_prov);
        }
    }

    public sealed class SampleKeyProvider : KeyProvider
    {
        public override string Name
        {
            get { return "Sample Key Provider"; }
        }

        public override byte[] GetKey(KeyProviderQueryContext ctx)
        {
            Form1 dlg = new Form1();
            UIUtil.ShowDialogAndDestroy(dlg);
            if(dlg.InitEx() != "123456") { MessageBox.Show(dlg.InitEx()); return null; }
            
            else return new byte[] {1};
        }
    }
}
